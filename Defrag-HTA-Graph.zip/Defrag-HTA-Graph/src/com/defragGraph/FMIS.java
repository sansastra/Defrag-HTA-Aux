package com.defragGraph;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Sandeep on 19-Jul-16.
 */
public class FMIS {
    int num_node;
   private int[][] graph;
    int[] max_ind_set;
    char[] visited_node;
    int[] G_node;
    int max_size;
    int size1;
    int[] ind_set;
    int[] G1;
    public FMIS( int[][] graph){
        this.graph=graph;
        num_node=graph.length;
        visited_node= new char[num_node];
        G_node= new int[num_node];
        for (int i=0; i<num_node;i++)
             G_node[i]= i;
        max_ind_set= new int[num_node];
        max_size = 0;
        size1=0;
        ind_set = new int[num_node];
        G1 = new int[num_node];
        for (int i = 0; i < num_node; i++)
            visited_node[i]='F';

    }

    //  The main function to find the MIS in FMIS algorithm.
    public void Gen_ind_set() {
        int v, counter = 0, x = 0;
        if (degree() == 0) {
            for (int i = 0; i < num_node; i++)
                if (visited_node[i] == 'F')
                    counter++;
            if (counter > max_size) {
                for (int i = 0; i < num_node; i++)
                    if (visited_node[i] == 'F')
                        max_ind_set[x++] = i;//G_node[i];
                max_size = x;
                size1 = x;
            }
        } else {
            v = select_node();
            size1 = 0;
            for (int i = 0; i < num_node; i++) {
                if (graph[v][i] == 0 && visited_node[i] != 'X')
                    ind_set[size1++] = i;
            }
            if (size1 > 2 && size1 > max_size)
                conflict();
            if (size1 > max_size) {
                max_size = size1;
                for (int i = 0; i < max_size; i++)
                    max_ind_set[i] = ind_set[i];
            }
            visited_node[v] = 'T';
            Gen_ind_set();
        }

    }

    // The degree function to find the degree of a given graph.
    public int degree() {
        int deg = 0;
        for (int i = 0; i < num_node; i++) {
            if (deg > 0)
                break;
            if (visited_node[i] != 'F')
                continue;
            for (int j = 0; j < num_node; j++) {
                if (graph[i][j] == 1 && visited_node[j] == 'F')
                    deg++;
                if (deg > 0) break;
            }
        }
        return deg;
    }

    // The select_node( ) function to select a vertex with the highest degree in a graph to be a candidate in MIS
    public int select_node() {
        int max1, max2 = 0, r = 0;
        for (int i = 0; i < num_node; i++) {
            max1 = 0;
            if (visited_node[i] != 'F')
                continue;
            for (int j = 0; j < num_node; j++)
                if (graph[i][j] == 1 && visited_node[j] == 'F')
                    max1++;
            if (max1 > max2) {
                r = i;
                max2 = max1;
            }
        }
        return r;
    }

    //The conflict() function in which to find an independent set.
    public void conflict() {
        int c = 0, del = 0, rm=0, J = 0;
        for (int i = 0; i < size1; i++) {
            c = 0;
            for (int j = 0; j < size1; j++)
                if (graph[ind_set[i]][ind_set[j]] == 1)
                    c++;
            if (c > del) {
                del = c;
                rm = ind_set[i];
            }
        }
        if (del > 0) {
            size1--;
            J = 0;
            for (int i = 0; i < num_node; i++)
                if (rm != ind_set[i] && J < size1)
                    G1[J++] = ind_set[i];
            for (int i = 0; i < J; i++)
                ind_set[i] = G1[i];
            size1 = J;
            conflict();
        }
    }

    public int[] getG1() {
        return G1;
    }

    public int getSize1() {
        return size1;
    }

    public int[] getMax_ind_set() {
        return Arrays.copyOfRange(max_ind_set, 0, size1);
    }

    public List<Integer> getMax_ind_node_List(){
        List<Integer> max_ind_node_List = new ArrayList<>();
        for (int i = 0; i < size1; i++) {
            max_ind_node_List.add(G_node[max_ind_set[i]]);
        }
        return max_ind_node_List;
    }

    public void setGraph(int[][] graph) {

        this.graph = graph;
    }
}
