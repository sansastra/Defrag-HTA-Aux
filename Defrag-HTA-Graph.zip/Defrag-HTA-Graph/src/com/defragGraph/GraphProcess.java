package com.defragGraph;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by Sandeep on 22-Jul-16.
 */
public class GraphProcess {
    private List<List<Integer>> graph;
    List<Integer> G_node;

    public GraphProcess(List<List<Integer>> initialGraph) {
        graph = new ArrayList<>();
        graph.addAll(initialGraph);
        G_node = new ArrayList<>();
        for (int i = 0; i < graph.size(); i++)
            G_node.add(i);

       // setInitialGraph(initialgraph);
    }


    public int[][] modifyGraph(List<Integer> delete_nodes) {
        List<Integer> G_node1 = new ArrayList<>();
        //List<List<Integer>> graph1 = new ArrayList<>();
        G_node1.addAll(G_node); // G_node1 = G_node will not work, G_node1 will change with G_node
//        graph1.addAll(graph);
        for (int i = 0; i < delete_nodes.size(); i++) {
            graph.remove(G_node.indexOf(delete_nodes.get(i)));  // remove the the connecting edges
            G_node.remove(G_node.indexOf(delete_nodes.get(i))); // remove the node deleted_nodes
        }
        List<Integer> G_node2;
        for (int i = 0; i < G_node.size(); i++) {
            G_node2 = new ArrayList<>();
            G_node2.addAll(G_node1);
            for (int j = 0; j < delete_nodes.size(); j++) {
                graph.get(i).remove(G_node2.indexOf(delete_nodes.get(j)));
                G_node2.remove(G_node2.indexOf(delete_nodes.get(j)));
            }
        }
        return getNew_graph();
    }

    public int[] getG_node() {
        int[] G_node1 = new int[G_node.size()];
        for (int i = 0; i < G_node.size(); i++) {
            G_node1[i] = G_node.get(i);
        }
        return G_node1;
    }

    public int getG_nodeSize() {
        return G_node.size();
    }

    public int[][] getNew_graph() {
        int size = G_node.size();
        int new_graph[][] = new int[size][size];
        for (int i = 0; i < G_node.size(); ++i) {
            for (int j = 0; j < G_node.size(); j++) {
                new_graph[i][j] = graph.get(i).get(j);
            }
        }

        return new_graph;
    }

    public int getSizeOfGraph(){
        return G_node.size();
    }
}


//    public void setInitialGraph(List<List<Integer>> initialGraph) {
//
//        switch (type){
//            case 1:
//                initialGraph = new int[][]{
//                        {0, 1, 0, 0, 0, 1},
//                        {1, 0, 1, 0, 1, 0},
//                        {0, 1, 0, 1, 0, 0},
//                        {0, 0, 1, 0, 1, 0},
//                        {0, 1, 0, 1, 0, 1},
//                        {1, 0, 0, 0, 1, 0}
//                };
//                break;
//            case 2:
//                initialGraph = new int[][]{
//                        {0, 0, 1, 1, 1},
//                        {0, 0, 1, 1, 1},
//                        {1, 1, 0, 1, 1},
//                        {1, 1, 1, 0, 1},
//                        {1, 1, 1, 1, 0}
//                };
//                break;
//            case 3:
//                initialGraph = new int[][]{
//                        {0, 1, 1, 1, 1},
//                        {1, 0, 0, 1, 0},
//                        {1, 0, 0, 0, 1},
//                        {1, 1, 0, 0, 1},
//                        {1, 0, 1, 1, 0}
//                };
//                break;
//        }
//
//
//
//
//
//        for (int i = 0; i < initialGraph.length; i++) {
//            graph.add(new ArrayList<>());
//            for (int j = 0; j < initialGraph.length; j++) {
//                graph.get(i).add(j, initialGraph[i][j]);
//            }
//        }
//        // return initialGraph;
//    }