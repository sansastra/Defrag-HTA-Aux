package com.auxiliarygraph;

import com.auxiliarygraph.elements.Connection;
import com.auxiliarygraph.elements.FiberLink;
import com.auxiliarygraph.elements.LightPath;
import com.auxiliarygraph.elements.Path;
import com.graph.elements.edge.EdgeElement;
import com.graph.elements.vertex.VertexElement;
import com.graph.graphcontroller.Gcontroller;
import com.graph.path.PathElement;
import com.inputdata.InputParameters;
import com.launcher.SimulatorParameters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Created by Fran on 6/12/2015.
 */
public class NetworkState {

    private static Map<String, FiberLink> fiberLinksMap;
    private static List<LightPath> listOfLightPaths;
    private static List<Path> listOfPaths;
    private static double transponderCapacity;
    private static int numOfMiniGridsPerGB;
    private static double totalNumberOfSlots;
    private static List<Integer> listOfPossibleGrids;

    private static final Logger log = LoggerFactory.getLogger(NetworkState.class);

    public NetworkState(Gcontroller graph, double granularity, int capacity, int txCapacityOfTransponders, int numOfMiniGridsPerGB, Set<PathElement> setOfPathElements, int policy) {

        this.fiberLinksMap = new HashMap<>();
        this.listOfLightPaths = new ArrayList<>();
        this.listOfPaths = new ArrayList<>();
        this.transponderCapacity = txCapacityOfTransponders / granularity;
        this.numOfMiniGridsPerGB = numOfMiniGridsPerGB;
        this.totalNumberOfSlots = capacity/granularity;
        for (PathElement pe : setOfPathElements)
            listOfPaths.add(new Path(pe));

        for (EdgeElement edgeElement : graph.getEdgeSet())
            fiberLinksMap.put(edgeElement.getEdgeID(), new FiberLink((int)totalNumberOfSlots, edgeElement));

        new Weights(policy);
        listOfPossibleGrids= new ArrayList<>();
    }

    public static List<LightPath> getListOfLightPaths(List<Path> listOfCandidatePaths) {
        List<LightPath> listOfLightPaths = new ArrayList<>();

        for (Path p : listOfCandidatePaths) {
            List<VertexElement> vertexElements = p.getPathElement().getTraversedVertices();
//            for (int i = 0; i < vertexElements.size() - 1; i++)
//                for (int j = i + 1; j < vertexElements.size(); j++) {
//                    List<LightPath> tmpListOfLP = getListOfLightPaths(vertexElements.get(i), vertexElements.get(j));
            List<LightPath> tmpListOfLP = getListOfLightPaths(vertexElements.get(0), vertexElements.get(vertexElements.size() - 1));
                    for (LightPath lp : tmpListOfLP)
                        if (!listOfLightPaths.contains(lp))
                            listOfLightPaths.add(lp);
                }
      //  }

        return listOfLightPaths;
    }

    public static List<LightPath> getListOfLightPaths(VertexElement src, VertexElement dst) {
        List<LightPath> lightPaths = new ArrayList<>();

        for (LightPath lp : listOfLightPaths)
            if (lp.getPathElement().getSource().equals(src) && lp.getPathElement().getDestination().equals(dst))
                lightPaths.add(lp);

        return lightPaths;
    }

    public static PathElement getPathElement(List<VertexElement> vertexes) {

        for (Path path : listOfPaths)
            if (path.getPathElement().getTraversedVertices().equals(vertexes))
                return path.getPathElement();

        return null;
    }

    public static List<Path> getListOfPaths(String src, String dst) {

        List<Path> listOfCandidatePaths = new ArrayList<>();
        for (Path p : listOfPaths)
            if (p.getPathElement().getSourceID().equals(src) && p.getPathElement().getDestinationID().equals(dst))
                listOfCandidatePaths.add(p);

        return listOfCandidatePaths;
    }

    public static FiberLink getFiberLink(String edgeID) {
        return fiberLinksMap.get(edgeID);
    }

    public static Map<String, FiberLink> getFiberLinksMap() {
        return fiberLinksMap;
    }

    public static List<LightPath> getListOfLightPaths() {
        return listOfLightPaths;
    }

    public static double getTransponderCapacity() {
        return transponderCapacity;
    }

    public static int getNumOfMiniGridsPerGB() {
        return numOfMiniGridsPerGB;
    }
    public static List<Path> getListOfPaths() {return listOfPaths;}
    /**
     * Experimental
     */
   /* public void applyDefragmentation(LightPath leavingLP, Connection leavingConnection) {

        Set<LightPath> candidateLightPathsToReconfigure = new HashSet<>();

        for (LightPath lp : listOfLightPaths)
            if (lp.getFirstMiniGrid() > leavingConnection.getMiniGrid())
                for (EdgeElement e : leavingLP.getPathElement().getTraversedEdges())
                    if (lp.getPathElement().isLinktraversed(e))
                        candidateLightPathsToReconfigure.add(lp);

    }
*/
    public static Set<FiberLink> getNeighborsFiberLinks(VertexElement src, VertexElement dst) {

        Set<FiberLink> neighboursFiberLinks = new HashSet<>();
        for (EdgeElement e : InputParameters.getGraph().getEdgeSet())
            if (e.getDestinationVertex().getVertexID().equals(src.getVertexID()) || e.getSourceVertex().getVertexID().equals(dst.getVertexID()))
                neighboursFiberLinks.add(fiberLinksMap.get(e.getEdgeID()));

        return neighboursFiberLinks;
    }

    public static List<LightPath> getListOfTraversingLightPaths(EdgeElement link) {
        List<LightPath> listOfLPs = new ArrayList<>();
        List<LightPath> listOfExistingLPs = getListOfLightPaths();
        for (LightPath lp : listOfExistingLPs) {
            if (lp.getPathElement().getTraversedEdges().contains(link))
                listOfLPs.add(lp);
        }

        return listOfLPs;
    }

    public static int getFirstGridForReassignment(String src, String dst, int demand){
        Path p = getListOfPaths(src,dst).get(0);
        for (int i = 1; i <= (int)totalNumberOfSlots; i++) {
            int count=0;
            for (EdgeElement e : p.getPathElement().getTraversedEdges()){
                if (getFiberLink(e.getEdgeID()).areNextMiniGridsAvailable(i,demand))
                    count++;
                else
                    break;
            }
            if(count== p.getPathElement().getTraversedEdges().size()) {
                return i;
            }
        }

        return Integer.MAX_VALUE;
    }

    public static List<BitSet> getAllGridsForReassignment(LightPath lp, int reservedGrid, int reserveBandwidth){
        List<BitSet> possibleGrids= new ArrayList<>();
        listOfPossibleGrids.clear();
        BitSet grids;
        //Path p = lp.getPathElement();//getListOfPaths(src,dst).get(0);
        int demand = lp.getLPbandwidth();
        for (int i = 1; i <= (int)totalNumberOfSlots-demand+1; i++) {
            if (i<reservedGrid-demand+1 || i> reservedGrid+reserveBandwidth-1) {
                int count = 0;
                for (EdgeElement e : lp.getPathElement().getTraversedEdges())
                    if (getFiberLink(e.getEdgeID()).areNextMiniGridsAvailable(i, demand))
                        count++;
                    else
                        break;
                if (count == lp.getPathElement().getTraversedEdges().size()){
                    grids = new BitSet((int)totalNumberOfSlots);
                    grids.set(i,i+demand); // start is 0, uper index is not included while setting up,
                    possibleGrids.add(grids);
                    listOfPossibleGrids.add(i);
                }

            }
        }

        return possibleGrids;
    }

     public static double getNetworkFragmentationIndex() {
        double fragmentationIndex = 0;
         double timeFI =0;
         double meanHT = InputParameters.getMeanHoldingTimes();
         List<EdgeElement> linkFragmentationList=new ArrayList<>();
        for(LightPath lp : listOfLightPaths)
            for (EdgeElement e : lp.getPathElement().getTraversedEdges()) {
                if(!linkFragmentationList.contains(e)){
                    linkFragmentationList.add(e);
                    FiberLink fl = NetworkState.getFiberLink(e.getEdgeID());
                    fragmentationIndex += fl.getLinkFragmentationMetric();
                    timeFI += fl.getLinkTimeFragmentationIndex(meanHT);
                }
        }

        return 0.5*(fragmentationIndex+timeFI)/linkFragmentationList.size();

    }

    public static boolean getIfTwoLPstraversesACommonLink(LightPath lp1, LightPath lp2){
        for (EdgeElement e1:lp1.getPathElement().getTraversedEdges())
            for (EdgeElement e2:lp2.getPathElement().getTraversedEdges())
                if (e1==e2)
                    return true;
        return false;
    }

    public static int getTotalNumberOfSlots() {
        return (int)totalNumberOfSlots;
    }

    public static List<Integer> getPossibleGrids4Reconfig(){
        return listOfPossibleGrids;
    }
}
