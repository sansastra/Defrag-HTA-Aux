package com.defragGraph;

import com.auxiliarygraph.NetworkState;
import com.auxiliarygraph.elements.Connection;
import com.auxiliarygraph.elements.FiberLink;
import com.auxiliarygraph.elements.LightPath;
import com.graph.elements.edge.EdgeElement;
import com.simulator.elements.TrafficFlow;

import java.util.*;

/**
 * Created by Sandeep on 01-Aug-16.
 */
public class RecreateGraph {
    private  int currentGrid;
    private  int bandwidth;
    private int[][] graph;
    private  Map<Integer, BitSet> nodesToOccupancyMap;
    private  Map<LightPath,List<Integer>> lightpathToNodes;
    private  int size1;
    private  List<LightPath> lpToReconfigList;
    private  List<Integer> lpToGrid;
    private int numberOfConnections;
    public RecreateGraph(int bw){
        bandwidth =bw;
    }

    public  int[][] getConflictGraph(TrafficFlow selectedFlow, int startGrid){
        size1=0;
        numberOfConnections=0;
        currentGrid = startGrid;
        Set<LightPath> lpToReconfigSet= new HashSet<>();

       // lpToReconfigList = new ArrayList<>();
        List<LightPath> listOfLPs, debug;
        //  debug= NetworkState.getListOfLightPaths();
        for (EdgeElement e:selectedFlow.getListOfPaths().get(0).getPathElement().getTraversedEdges()) {
            listOfLPs = NetworkState.getListOfTraversingLightPaths(e);
            for (LightPath lp1:listOfLPs)
                for (int initialGrid = currentGrid; initialGrid < currentGrid+ bandwidth ; initialGrid++)
                    if (lp1.containsMiniGrid(initialGrid))
                        lpToReconfigSet.add(lp1);
        }
        lpToReconfigList = new ArrayList<>(lpToReconfigSet);
        boolean ifSolutionPossible = getAllsolutions();
        if(!ifSolutionPossible)
            return new int[0][0];
        if (size1==1)
            graph=new int[size1][size1]; //graph[0][0]=0
        else
           generateGraph();

        return graph;
    }


    public  boolean getAllsolutions(){
        lpToGrid = new ArrayList<>();
        List<List<BitSet>> possibleSolutionsList= new ArrayList<>();
        nodesToOccupancyMap = new HashMap<>();
        lightpathToNodes = new HashMap<>();
        List<Integer> tempList;
        int i=0;
        for (LightPath lp:lpToReconfigList) {
            possibleSolutionsList.add(new ArrayList<>());
            possibleSolutionsList.get(i).addAll(NetworkState.getAllGridsForReassignment(lp,currentGrid,  bandwidth));
            if (possibleSolutionsList.get(i).size()==0)
                return false;
            tempList = new ArrayList<>();
            List<Integer> tempList2=NetworkState.getPossibleGrids4Reconfig();
            for (int j = 0; j <possibleSolutionsList.get(i).size() ; j++) {
                nodesToOccupancyMap.put(size1,possibleSolutionsList.get(i).get(j));
                lpToGrid.add(tempList2.get(j));
                tempList.add(size1);
                size1++;
            }
            lightpathToNodes.put(lp,tempList);
            i++;
        }
        return true;
    }

    public  void generateGraph(){
        graph=new int[size1][size1];
        BitSet temp;
        for (LightPath lp1:lpToReconfigList)
            for (LightPath lp2:lpToReconfigList)
                if (lp1!=lp2) {
                    if (NetworkState.getIfTwoLPstraversesACommonLink(lp1, lp2))
                        for (int i : lightpathToNodes.get(lp1))
                            for (int j : lightpathToNodes.get(lp2)) {
                                temp = (BitSet) nodesToOccupancyMap.get(i).clone();
                                temp.and(nodesToOccupancyMap.get(j));
                                if (temp.cardinality() > 0) {
                                    graph[i][j] = 1;
                                    graph[j][i] = 1;
                                }
                            }
                }
                else {
                    for (int i : lightpathToNodes.get(lp1))
                        for (int j : lightpathToNodes.get(lp2))
                            if (i != j) {
                                graph[i][j] = 1;
                                graph[j][i] = 1;
                            }
                }
    }


    public  int getNumberOfLPs(){
        return lpToReconfigList.size();
    }
    public List<LightPath> getLPtobeReconfigured(){return lpToReconfigList;}
    public List<Integer> getLPtoGrid(){return lpToGrid;}

    public Map<LightPath,Integer> getLPtoReconfigure(List<Integer> lpIndex){
        Map<LightPath,Integer> reconfigLPtoGrids=new HashMap<>();
        int i=0;
        for (LightPath lp:lpToReconfigList) {
            reconfigLPtoGrids.put(lp,lpToGrid.get(lpIndex.get(i)));
            i++;
        }
        return reconfigLPtoGrids;
    }

    public void reconfigLPs(int[] lpIndex){
        int i=0;
        for (LightPath lp:lpToReconfigList) {
            int demand=lp.getLPbandwidth();
            lp.releaseAllMiniGrids();
            lp.removeAllMinigridIDs();
            lp.setMinigridIDs(lpToGrid.get(lpIndex[i]), demand);
            lp.setAllMiniGrids();
            numberOfConnections += lp.getConnectionMap().size();
            i++;
        }
    }

    public int getNumberOfConnections(){ return numberOfConnections;}
}


//    public  int[][] getConflictGraph(TrafficFlow selectedFlow, int startGrid){
//        size1=0;
//        currentGrid = startGrid;
//
//        lpToReconfigList = new ArrayList<>();
//        List<LightPath> listOfLPs, debug;
//      //  debug= NetworkState.getListOfLightPaths();
//        for (EdgeElement e:selectedFlow.getListOfPaths().get(0).getPathElement().getTraversedEdges()) {
//            listOfLPs = NetworkState.getListOfTraversingLightPaths(e);
//            for (LightPath lp1:listOfLPs)
//                for (int initialGrid = currentGrid; initialGrid < currentGrid+ bandwidth ; initialGrid++)
//                    if (lp1.containsMiniGrid(initialGrid))
//                        lpToReconfigList.add(lp1);
//        }
//
//        boolean ifSolutionPossible = getAllsolutions();
//        if(!ifSolutionPossible)
//            return new int[0][0];
//        findEdgesToGraph();
//        generateGraph();
//
//        return graph;
//    }
//
//
//    public  boolean getAllsolutions(){
//        lpToGrid = new ArrayList<>();
//        NodesTolightpath= new HashMap<>();
//        possibleSolutionsList= new ArrayList<>();
//        nodesToOccupancyMap = new HashMap<>();
//        lightpathToNodes = new HashMap<>();
//        conflictBetweenNodes = new HashMap<>();
//        List<Integer> tempList;
//        int i=0;
//        for (LightPath lp:lpToReconfigList) {
//            possibleSolutionsList.add(new ArrayList<>());
//            possibleSolutionsList.get(i).addAll(NetworkState.getAllGridsForReassignment(lp,currentGrid,  bandwidth));
//            if (possibleSolutionsList.get(i).size()==0)
//                return false;
//            tempList = new ArrayList<>();
//            List<Integer> tempList2=NetworkState.getPossibleGrids4Reconfig();
//            for (int j = 0; j <possibleSolutionsList.get(i).size() ; j++) {
//                nodesToOccupancyMap.put(size1,possibleSolutionsList.get(i).get(j));
//                lpToGrid.add(tempList2.get(j));
//                tempList.add(size1);
//                conflictBetweenNodes.put(size1,new ArrayList<>());
//                size1++;
//            }
//            lightpathToNodes.put(lp,tempList);
//            i++;
//        }
//        return true;
//    }
//
//    public  void findEdgesToGraph(){
//        List<Integer> tempNodesList1, tempNodesList2;
//        BitSet temp = new BitSet(NetworkState.getTotalNumberOfSlots());
//        for (LightPath lp1:lpToReconfigList) {
//            for (LightPath lp2:lpToReconfigList) {
//                if (NetworkState.getIfTwoLPstraversesACommonLink(lp1, lp2)){
//                    for (int i:lightpathToNodes.get(lp1)) {
//                        for (int j:lightpathToNodes.get(lp2)) {
//                            if (lp1==lp2 && i!=j){
//                                tempNodesList1 = new ArrayList<>();
//                                tempNodesList1.addAll(conflictBetweenNodes.get(i));
//                                tempNodesList1.add(j);
//                                conflictBetweenNodes.replace(i, tempNodesList1);
//                            }
//                            else if (!conflictBetweenNodes.get(i).contains(j)&& i!=j){
//                               // List<Integer> common = new ArrayList<Integer>(listA);
//                                temp= (BitSet) nodesToOccupancyMap.get(i).clone();
//                                temp.and(nodesToOccupancyMap.get(j));
//                                if (temp.cardinality()>0) {
//                                    tempNodesList1 = new ArrayList<>();
//                                    tempNodesList1.addAll(conflictBetweenNodes.get(i));
//                                    tempNodesList1.add(j);
//                                    conflictBetweenNodes.replace(i, tempNodesList1);
//                                }
//                            }
//                        }
//
//                    }
//                }
//            }
//        }
//    }
//    public  void generateGraph(){
//        graph=new int[size1][size1];
//        for (int i = 0; i <size1; i++)
//            for (int j = 0; j <size1 ; j++)
//                if(conflictBetweenNodes.get(i).contains(j))
//                    graph[i][j]=1;
//                else
//                    graph[i][j]=0;
//
//    }






//        listOfNodes = new ArrayList<>();
//        Map<EdgeElement,Integer> conflictMinigridMap = new HashMap<>();
//        List<Integer> listOfLPindex;
//        int temp;
//
//        for (int i = 0; i <possibleSolutionsList.size() ; i++) {
//            for (int j = 0; j <possibleSolutionsList.get(j).size() ; j++) {
//                if (possibleSolutionsList.get(i).get(j)!=null) {
//                    listOfNodes.add(size1);
//                    for(EdgeElement e : lpToReconfigList.get(i).getPathElement().getTraversedEdges()) {
//                        listOfLPindex = new ArrayList<>();
//                        if (conflictMinigridMap.containsKey(e)) {
//                            listOfLPindex.addAll(conflictMinigridMap.get(e));
//
//                            listOfLPindex.add(size1);
//                            conflictMinigridMap.replace(e, listOfLPindex);
//                        } else {
//                            listOfLPindex.add(size1);
//                            conflictMinigridMap.put(e, listOfLPindex);
//                        }
//
//                    }
//                    size1++;
//                }
//            }
//        }



//    public  List<List<Integer>> getConflictGraph(LightPath lp){
//        Set<LightPath> lpToReconfigureSet = new HashSet<LightPath>();
//        bandwidth =lp.getAllConectionsBandwidth();
//        List<LightPath> listOfLPs;
//        for (EdgeElement e:lp.getPathElement().getTraversedEdges()) {
//            listOfLPs = NetworkState.getListOfTraversingLightPaths(e);
//            for (LightPath lp1:listOfLPs)
//                for (int initialGrid = currentGrid; initialGrid < currentGrid+ bandwidth ; initialGrid++)
//                    if (lp1.containsMiniGrid(initialGrid))
//                        lpToReconfigureSet.add(lp1);
//        }
//        lpToReconfigList=  new ArrayList<>(lpToReconfigureSet);
//        boolean ifSolutionPossible = getAllsolutions();
//        if(!ifSolutionPossible)
//            return graph;
//        findEdgesToGraph();
//        generateGraph();
//
//    return graph;
//    }