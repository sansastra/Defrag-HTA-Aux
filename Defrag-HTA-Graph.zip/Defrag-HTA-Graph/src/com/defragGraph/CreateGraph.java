package com.defragGraph;

import com.auxiliarygraph.NetworkState;
import com.auxiliarygraph.elements.Connection;
import com.auxiliarygraph.elements.LightPath;
import com.graph.elements.edge.EdgeElement;
import com.inputdata.InputParameters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Created by Sandeep on 25-Jul-16.
 */
public class CreateGraph {
    private static List<String> nodelist;
    private static List<List<Integer>> graph;
    // Flows

    private static int[] Demand;			// Traffic demand of the flows
    private static List<List<String>> flowInfo ;
    private static List<Integer> hopLength;

    private static int size1;


    public CreateGraph(){
        Set<String> nodenames;
        nodenames = InputParameters.getSetOfVertexIDSets();

        int N = nodenames.size();
        nodelist = new ArrayList<>(nodenames);
        // nodeElementsList = new ArrayList<>(nodeElementsSet);
        // Flows
        int F;					// Number of flows
        F = N * (N - 1);
        Demand = new int[F];
        flowInfo = new ArrayList<>();
        hopLength = new ArrayList<>();
        graph = new ArrayList<>();
        size1 =0;
    };


    private static final Logger log = LoggerFactory.getLogger(CreateGraph.class);


    public List<List<Integer>> mapLightpathsToEdges() {
        Map<Double, Connection> connectioTomap;
        Map<EdgeElement,List<Integer>> linkLightpathMap= new HashMap<>();;
        // VertexElement ver1 =nodeElementsList.get(0), ver2=nodeElementsList.get(0);
        List<LightPath> lightpaths;

        //InputParameters.getIfConnectiongEdge(node,node1)

        for (String node : nodelist) {
            for (String node1 : nodelist) {
                if (!node.equals(node1)) {
                    lightpaths = NetworkState.getListOfLightPaths(InputParameters.getGraph().getVertex(node), InputParameters.getGraph().getVertex(node1));
                    int demand = 0;
                    for (LightPath lp : lightpaths) {
                        demand = lp.getAllConectionsBandwidth();
                        lp.releaseAllMiniGrids();
                        lp.removeAllMinigridIDs();
                    }
                    if(demand>0) {
                        List<Integer> listOfLPindex;
                        for(EdgeElement e : lightpaths.get(0).getPathElement().getTraversedEdges()) {
                            listOfLPindex = new ArrayList<>();
                            if (linkLightpathMap.containsKey(e)){
                                listOfLPindex.addAll(linkLightpathMap.get(e));
                                listOfLPindex.add(size1);
                                linkLightpathMap.replace(e, listOfLPindex);
                            }
                            else {
                                listOfLPindex.add(size1);
                                linkLightpathMap.put(e, listOfLPindex);
                            }
                        }
                        flowInfo.add(new ArrayList<>());
                        flowInfo.get(size1).add(node); //source
                        flowInfo.get(size1).add(node1); // destination
                        flowInfo.get(size1).add(String.valueOf(demand)); // demand
                        hopLength.add(NetworkState.getListOfPaths(node, node1).get(0).getListOfFiberLinks().size());
                       // flowInfo.get(size1).add(String.valueOf(hopLength.get(size1)));
                        Demand[size1]= demand;
                        size1++;
                    }

                }
            }

        }

        // Arrange connections in decreasing order of there hop lengths
      //  sorting();
        // find lightpaths that traverse on same link
        // create graph
        for (int i = 0; i <size1; i++) {
            graph.add(new ArrayList<>());
            for (int j = 0; j <size1 ; j++) {
                if(Demand[i]!= Demand[j])
                    graph.get(i).add(j,1);
                else
                    graph.get(i).add(j,0);
            }

        }
        // now connect two nodes (LP) if they overlap
        List<Integer> listOfLPindex;
        for (Map.Entry<EdgeElement, List<Integer>> entry : linkLightpathMap.entrySet()) {
            listOfLPindex = new ArrayList<>();
            listOfLPindex.addAll(entry.getValue());
            for (int i=0; i<listOfLPindex.size();i++) {
                for (int j=i+1; j<listOfLPindex.size();j++) {
                    graph.get(listOfLPindex.get(i)).set(listOfLPindex.get(j),1);
                    graph.get(listOfLPindex.get(j)).set(listOfLPindex.get(i),1);
                    // graph.get(oldToNewLPindex.get(listOfLPindex.get(i))).set(oldToNewLPindex.get(listOfLPindex.get(j)),1);
                   // graph.get(oldToNewLPindex.get(listOfLPindex.get(j))).set(oldToNewLPindex.get(listOfLPindex.get(i)),1);
                }
            }
        }
        return graph;
    }

    public static List<List<String>> getFlowInfo(){
        return flowInfo;
    }

    public static List<Integer> getHopLength(){
        return hopLength;
    }

    public static int[] getDemand(){
        return Demand;
    }

    public static List<String> getNodeList(){
        return nodelist;
    }
}
