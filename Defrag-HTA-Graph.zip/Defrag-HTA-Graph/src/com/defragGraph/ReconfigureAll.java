package com.defragGraph;

import com.auxiliarygraph.NetworkState;
import com.auxiliarygraph.elements.Connection;
import com.auxiliarygraph.elements.LightPath;
import com.graph.elements.edge.EdgeElement;
import com.inputdata.InputParameters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Created by Sandeep on 25-Jul-16.
 */
public class ReconfigureAll {

    public ReconfigureAll(){};

    private static final Logger log = LoggerFactory.getLogger(CreateGraph.class);

    // set minigrid for lightpaths
    public List<LightPath> execute(List<List<Integer>> max_ind_List){
        List<LightPath> lightpaths;
        List<LightPath> notEstablishedLP=new ArrayList<>();
        for (int i = 0; i < max_ind_List.size(); i++) {
            for (int j = 0; j < max_ind_List.get(i).size(); j++) {
                String node = CreateGraph.getFlowInfo().get(max_ind_List.get(i).get(j)).get(0);
                String node1 = CreateGraph.getFlowInfo().get(max_ind_List.get(i).get(j)).get(1);
                int totalDemand = Integer.valueOf(CreateGraph.getFlowInfo().get(max_ind_List.get(i).get(j)).get(2));
                lightpaths= NetworkState.getListOfLightPaths(InputParameters.getGraph().getVertex(node), InputParameters.getGraph().getVertex(node1));
                int intialMinigridID = NetworkState.getFirstGridForReassignment(node,node1,totalDemand);
                if(intialMinigridID <Integer.MAX_VALUE)
                    reassignLightpath(intialMinigridID, lightpaths);
                else{
                    lightpaths = tryToreassignLPs(node, node1,lightpaths);
                    notEstablishedLP.addAll(lightpaths);
                }


            }
        }
        return notEstablishedLP;
    }

    public List<Integer> sortHopLength(List<List<Integer>> temp_List1){
        Collections.sort(temp_List1, new Comparator<List<Integer>>() {
            @Override
            public int compare(List<Integer> o1, List<Integer> o2) {
                return o1.get(1).compareTo(o2.get(1));
            }
        });
        Collections.reverse(temp_List1);
        List<Integer> tempList= new ArrayList<>();
        for (int i = 0; i <temp_List1.size() ; i++) {
            tempList.add(temp_List1.get(i).get(0));
        }
        return tempList;
    }

    public List<List<Integer>> sortMax_ind_list(List<List<Integer>> max_ind_List){
        List<List<Integer>> temp_max_ind_list;
        List<List<Integer>> temp_List2D= new ArrayList<>();; // for hop soring
        List<List<Integer>> temp_List2D_demand=new ArrayList<>();
        List<Integer> temp_List1D;
        // sort  sets based on hops
        for (int i = 0; i < max_ind_List.size() ; i++) {
            temp_List2D.add(new ArrayList<>());
            temp_List2D.get(i).add(i);
            int max = 0;
            for (int j = 0; j < max_ind_List.get(i).size(); j++) {
                if (CreateGraph.getHopLength().get(max_ind_List.get(i).get(j)) > max)
                    max = CreateGraph.getHopLength().get(max_ind_List.get(i).get(j));
            }
            temp_List2D.get(i).add(max);
        }
        temp_List1D=sortHopLength(temp_List2D);
        temp_max_ind_list = new ArrayList<>();
        for (int i = 0; i < max_ind_List.size(); i++) {
            temp_max_ind_list.add(new ArrayList<Integer>());
            temp_max_ind_list.get(i).addAll(max_ind_List.get(temp_List1D.get(i)));
        }

        return temp_max_ind_list;
    }

    public void reassignLightpath(int intialMinigridID, List<LightPath> lightpaths) {
        // make it from 1 to total number of slots
        Map<Double, Connection> connectioTomap;
        for (LightPath lp : lightpaths) {
            int demand = lp.getAllConectionsBandwidth();
            lp.setMinigridIDs(intialMinigridID, demand);
            lp.setAllMiniGrids();
            // lp.reconfigureAllConnections(intialMinigridID, demand);
            intialMinigridID = intialMinigridID + demand;
        }
    }

    public List<LightPath> tryToreassignLPs(String node, String node1, List<LightPath> lightpaths){
        Map<Double, Connection> connectioTomap;
        List<LightPath> notEstablishedLightPaths=new ArrayList<>();
        for (LightPath lp : lightpaths) {
            int demand  = lp.getAllConectionsBandwidth();
            int intialMinigridID = NetworkState.getFirstGridForReassignment(node,node1,demand);
            if(intialMinigridID <Integer.MAX_VALUE) {
                lp.setMinigridIDs(intialMinigridID, demand);
                lp.setAllMiniGrids();
            }
            else{
                // start creating another graph
                notEstablishedLightPaths.add(lp);
                log.error("problem in reassigning connections");
            }


        }
        return notEstablishedLightPaths;
    }
}
