package com.defragGraph;

import com.auxiliarygraph.NetworkState;
import com.auxiliarygraph.elements.LightPath;
import com.graph.elements.vertex.VertexElement;
import com.simulator.elements.TrafficFlow;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

/**
 * Created by Sandeep on 25-Jul-16.
 */
public class MainDefragClass {
    int[] max_ind_set;
    int[][] GRAPH;
    TrafficFlow selectedFlow;
    int bandwidth;
    VertexElement src;
    List<Integer> gridlist;
    List<Integer> gridlist1;
    boolean defragSuccessful=false;
    int guardBand=0;
    int numberOfdisruptions=0;

    private static final Logger log = LoggerFactory.getLogger(MainDefragClass.class);
    public MainDefragClass(TrafficFlow selectedFlow, int bandwidth, VertexElement src){
        this.selectedFlow= selectedFlow;
        this.bandwidth=bandwidth;
        this.src=src;
    }

    public boolean startDefrag() {

        // see if a lightpath can be expanded
        if (NetworkState.getTransponderCapacity()>0){
            gridlist=new ArrayList<>();
            for (LightPath lp:NetworkState.getListOfLightPaths(src,selectedFlow.getDstNode())) {
                if(lp.getFirstMiniGrid()-bandwidth>0)
                    gridlist.add(lp.getFirstMiniGrid()-bandwidth);
                if (lp.getFirstMiniGrid()+lp.getLPbandwidth()+bandwidth-1<=NetworkState.getTotalNumberOfSlots())
                    gridlist.add(lp.getFirstMiniGrid()+lp.getLPbandwidth());
            }
            if (gridlist.size()>0){
                generateGraph(gridlist,guardBand);
                if (defragSuccessful)
                    return true;
            }
        }
        guardBand=NetworkState.getNumOfMiniGridsPerGB();

        gridlist1=new ArrayList<>();
        for (int i = 1; i <= NetworkState.getTotalNumberOfSlots()-bandwidth-guardBand+1; i++) {
                gridlist1.add(i);
        }
        // if not then consider guardband as well
        generateGraph(gridlist1,guardBand);

//        try {
//            parallelExecution();
//        } catch(InterruptedException ex){
//            Thread.currentThread().interrupt();
//        }
//        catch(ExecutionException ex){
//            log.error("Problem executing worker: " + ex.getCause());
//        }

        return defragSuccessful;
    }

public void generateGraph(List<Integer> tempList,int guardBand){
    RecreateGraph recreateGraph = new RecreateGraph(bandwidth+guardBand);

    for (int i : tempList) {

        GRAPH = recreateGraph.getConflictGraph(selectedFlow,i);
        if (GRAPH.length == 0)
            continue;
        else if (GRAPH.length==1)
            max_ind_set= new int[1]; //max_ind_set[0]=0;
        else {
            //processGraph();
            FMIS fmis = new FMIS(GRAPH);
            fmis.Gen_ind_set();
            max_ind_set = fmis.getMax_ind_set();
        }
        if (max_ind_set.length == recreateGraph.getNumberOfLPs()) {
            recreateGraph.reconfigLPs(max_ind_set);
            defragSuccessful = true;
            numberOfdisruptions=recreateGraph.getNumberOfConnections();
            break;
        }
    }
}
    public int getNumberOfdisruptions(){
        return numberOfdisruptions;
    }

    public void processGraph(){
       // GraphProcess graph_process = new GraphProcess(GRAPH);
       // max_ind_List = new ArrayList<>();
      //  while (graph_process.getSizeOfGraph() > 0) {
            FMIS fmis = new FMIS(GRAPH);
            fmis.Gen_ind_set();
            max_ind_set=fmis.getMax_ind_set();// getMax_ind_node_List());
//            for (int i = 0; i < fmis.getSize1(); i++)
//                System.out.printf("%d ", fmis.getMax_ind_node_List().get(i));
//            System.out.printf("\n");
       //     fmis.setGraph(graph_process.modifyGraph(fmis.getMax_ind_node_List()));
      //  }
    }



//    public void parallelExecution() throws InterruptedException, ExecutionException {
//        Collection<Callable<Result>> tasks = new ArrayList<>();
//        for (int i = 1; i <= NetworkState.getTotalNumberOfSlots()-bandwidth-guardBand+1; i++) {
//            tasks.add(new Task(i) );
//        }
//
//
//        int numThreads = 4; //max 4 threads
//        ExecutorService executor = Executors.newFixedThreadPool(numThreads);
//        List<Future<Result>> results = executor.invokeAll(tasks);
//        for(Future<Result> result : results){
//            Result reconfigResult = result.get();
//            if (reconfigResult.SUCCESS) {
//                defragSuccessful = true;
//                reconfigureLPs(reconfigResult.tempList,reconfigResult.lpToReconfigure,reconfigResult.lpToGrid);
//                executor.shutdown();
//            }
//        }
//        executor.shutdown(); //always reclaim resources
//    }
//
//
//
//    private final class Task implements Callable<Result> {
//        Task(int i){
//            index = i;
//        }
//        /**  */
//        @Override public Result call() throws Exception {
//            return reportStatus(index);
//        }
//        private final int index;
//    }
//
//    private Result reportStatus(int i)  {
//        Result result = new Result();
//
//        RecreateGraph recreateGraph = new RecreateGraph(bandwidth+guardBand);
//        List<List<Integer>> GRAPH1 = recreateGraph.getConflictGraph(selectedFlow,i);
//        if (GRAPH1.size() != 0)
//            processGraph();
//        if (max_ind_List.get(0).size() == recreateGraph.getNumberOfLPs()) {
//            result.lpToReconfigure = recreateGraph.getLPtobeReconfigured();
//            result.numberOfdisruptions = max_ind_List.get(0).size();
//            result.tempList = max_ind_List.get(0);
//            result.SUCCESS = true;
//            result.lpToGrid= recreateGraph.getLPtoGrid();
//        }
//
//        return result;
//    }
//
//    private static final class Result {
//        List<Integer> tempList=new ArrayList<>();
//        Boolean SUCCESS;
//        Integer numberOfdisruptions=0;
//        List<LightPath> lpToReconfigure = new ArrayList<>();
//        List<Integer> lpToGrid = new ArrayList<>();
//        public boolean getIfSuccess(){return SUCCESS;}
//        public List<Integer> getMax_ind_List(){return tempList;}
//        public List<LightPath> getLPtobeReconfigured(){return lpToReconfigure;}
//        public Integer getNoOfdisruptions(){return numberOfdisruptions;}


//    }
}


//        CreateGraph createGraph = new CreateGraph();
//        GRAPH =createGraph.mapLightpathsToEdges();
//        processGraph();
//        ReconfigureAll reconfigAll= new ReconfigureAll();
//        List<List<Integer>> temp_max_ind_List;
//        List<List<String>> flowInfo =CreateGraph.getFlowInfo();
//        temp_max_ind_List=reconfigAll.sortMax_ind_list(max_ind_List);
//        List<LightPath> lightPaths= reconfigAll.execute(temp_max_ind_List);
//        if (!lightPaths.isEmpty()){
//           // RecreateGraph recreateGraph = new RecreateGraph();
//            for (LightPath lp:lightPaths) {
//                for (int i = 1; i <= NetworkState.getTotalNumberOfSlots(); i++) {
//                   RecreateGraph recreateGraph = new RecreateGraph(i);
//                    GRAPH=recreateGraph.getConflictGraph(lp);
//                    processGraph();
//                    if (max_ind_List.get(0).size()==recreateGraph.getSize())
//                        break;
//                }
//
//            }
//
//        }